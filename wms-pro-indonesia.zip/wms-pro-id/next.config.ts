import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: {
    serverActions: {
      bodySizeLimit: "4mb",
    },
  },
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "cf.shopee.co.id" },
      { protocol: "https", hostname: "p16-oec-va.ibyteimg.com" },
    ],
  },
};

export default nextConfig;
