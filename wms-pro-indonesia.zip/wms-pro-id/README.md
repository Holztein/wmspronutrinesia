# WMS Pro Indonesia

Warehouse Management System profesional untuk seller multi-marketplace Indonesia: Shopee, TikTok Shop, Lazada, Tokopedia, dan kanal manual.

## Tech Stack

- Next.js 15 App Router + TypeScript
- Tailwind CSS + shadcn/ui-style components + Lucide icons
- Next.js API Routes
- Prisma ORM + PostgreSQL Supabase/Neon
- NextAuth.js v5 Credentials + RBAC
- Supabase Realtime-ready channels
- Export PDF/Excel/CSV
- PWA manifest

## Cara Menjalankan

```bash
npm install
# opsional database lokal: docker compose up -d
cp .env.example .env
# isi DATABASE_URL, DIRECT_URL, AUTH_SECRET, AUTH_URL
npm run db:generate
npm run db:push
npm run db:seed
npm run dev
```

Buka `http://localhost:3000`.

Akun demo:

- Owner: `owner@wmspro.id` / `password123`
- Manager: `manager@wmspro.id` / `password123`
- Staff: `staff@wmspro.id` / `password123`
- Picker: `picker@wmspro.id` / `password123`
- Packer: `packer@wmspro.id` / `password123`

## Struktur Folder

```txt
wms-pro-id/
├─ prisma/
│  ├─ schema.prisma
│  └─ seed.ts
├─ public/
│  ├─ manifest.json
│  ├─ icon-192.png
│  └─ icon-512.png
├─ docs/
│  ├─ ARCHITECTURE.md
│  └─ API_INTEGRATION.md
├─ src/
│  ├─ app/
│  │  ├─ (auth)/login/page.tsx
│  │  ├─ (dashboard)/page.tsx
│  │  ├─ (dashboard)/inventory/page.tsx
│  │  ├─ (dashboard)/orders/page.tsx
│  │  ├─ (dashboard)/warehouse/page.tsx
│  │  ├─ (dashboard)/reports/page.tsx
│  │  ├─ (dashboard)/settings/page.tsx
│  │  └─ api/
│  ├─ components/
│  │  ├─ dashboard/
│  │  ├─ layout/
│  │  └─ ui/
│  ├─ lib/
│  │  ├─ marketplaces/
│  │  ├─ logistics/
│  │  ├─ export/
│  │  ├─ auth.ts
│  │  ├─ prisma.ts
│  │  ├─ rbac.ts
│  │  └─ validators.ts
│  └─ middleware.ts
├─ package.json
└─ .env.example
```

## Fitur yang Sudah Ada di Scaffold

- Dashboard KPI dan chart sales.
- Inventory multi-warehouse, SKU/variant, barcode/QR field, stock summary, low stock badge.
- Unified order inbox dengan filter placeholder dan status flow.
- Warehouse operations: receiving, picking, packing, shipping API workflow.
- Marketplace adapter pattern untuk Shopee, TikTok Shop, Lazada, Tokopedia.
- Logistics provider pattern untuk ongkir, shipment, tracking.
- Export laporan CSV/XLSX/PDF.
- NextAuth v5 + user seed + RBAC matrix.
- PWA manifest dan mobile bottom navigation untuk warehouse tablet/HP.
- Seed data realistis: 56 produk, 100+ varian, 210 order, 3 warehouse, 5 user, marketplace account, notifikasi, shipping rules.

## Deployment ke Vercel

1. Push project ke GitHub/GitLab.
2. Buat database PostgreSQL di Supabase atau Neon.
3. Set environment variables di Vercel:
   - `DATABASE_URL`
   - `DIRECT_URL`
   - `AUTH_SECRET`
   - `AUTH_URL=https://domain-anda.vercel.app`
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - API key marketplace/kurir sesuai kebutuhan.
4. Jalankan migrasi dari lokal atau CI:

```bash
npx prisma migrate deploy
npx prisma db seed
```

5. Deploy di Vercel.

## Production Hardening Checklist

- Ganti credentials seed dan aktifkan OAuth provider internal bila diperlukan.
- Enkripsi API key marketplace/kurir sebelum disimpan ke database.
- Tambahkan queue worker untuk sync order/inventory 5-15 menit: Inngest, Trigger.dev, QStash, atau cron Vercel.
- Tambahkan idempotency key pada webhook marketplace dan kurir.
- Tambahkan rate limiting pada API sync, import, export, dan stock adjustment.
- Buat printer integration untuk shipping label dan packing slip.
- Tambahkan storage Supabase/S3 untuk foto packing.
- Tambahkan test suite Playwright dan Vitest sebelum production.

## Dokumentasi Integrasi

Detail teknis ada di `docs/API_INTEGRATION.md`. Link resmi utama:

- Shopee Open Platform: https://open.shopee.com/
- TikTok Shop Partner Center: https://partner.tiktokshop.com/
- Lazada Open Platform: https://open.lazada.com/
- RajaOngkir/Komerce API: https://rajaongkir.com/docs
- Komship API: https://developer.komship.id/
- Shipper Developer Hub: https://logistics-docs.shipper.id/
- JNE API Dashboard: https://apidash.jne.co.id/
