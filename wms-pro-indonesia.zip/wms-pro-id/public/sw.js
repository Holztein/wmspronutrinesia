const CACHE_NAME = 'wms-pro-v1';
const OFFLINE_URLS = ['/', '/login', '/manifest.json'];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(OFFLINE_URLS)));
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))));
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  event.respondWith(fetch(req).then((res) => {
    const clone = res.clone();
    caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
    return res;
  }).catch(() => caches.match(req).then((cached) => cached || caches.match('/login'))));
});
