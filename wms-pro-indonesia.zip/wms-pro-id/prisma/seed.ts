import { PrismaClient, Marketplace, OrderPriority, OrderStatus, Role } from "@prisma/client";
import bcrypt from "bcryptjs";
import QRCode from "qrcode";
import { slugify } from "../src/lib/utils";

const prisma = new PrismaClient();
const rand = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
const pick = <T,>(arr: T[]) => arr[rand(0, arr.length - 1)];

async function main() {
  await prisma.activityLog.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.shipment.deleteMany();
  await prisma.returnItem.deleteMany();
  await prisma.returnOrder.deleteMany();
  await prisma.packingTaskItem.deleteMany();
  await prisma.packingTask.deleteMany();
  await prisma.pickTaskItem.deleteMany();
  await prisma.pickTask.deleteMany();
  await prisma.receivingItem.deleteMany();
  await prisma.receivingNote.deleteMany();
  await prisma.orderItem.deleteMany();
  await prisma.order.deleteMany();
  await prisma.marketplaceListing.deleteMany();
  await prisma.marketplaceAccount.deleteMany();
  await prisma.stockMovement.deleteMany();
  await prisma.stock.deleteMany();
  await prisma.variant.deleteMany();
  await prisma.product.deleteMany();
  await prisma.location.deleteMany();
  await prisma.warehouse.deleteMany();
  await prisma.shippingRule.deleteMany();
  await prisma.appSetting.deleteMany();
  await prisma.companyProfile.deleteMany();
  await prisma.user.deleteMany();

  const password = await bcrypt.hash("password123", 12);
  const users = await Promise.all([
    prisma.user.create({ data: { name: "Yahya Owner", email: "owner@wmspro.id", password, role: Role.OWNER } }),
    prisma.user.create({ data: { name: "Nadia Manager", email: "manager@wmspro.id", password, role: Role.MANAGER } }),
    prisma.user.create({ data: { name: "Dimas Staff Gudang", email: "staff@wmspro.id", password, role: Role.WAREHOUSE_STAFF } }),
    prisma.user.create({ data: { name: "Raka Picker", email: "picker@wmspro.id", password, role: Role.PICKER } }),
    prisma.user.create({ data: { name: "Maya Packer", email: "packer@wmspro.id", password, role: Role.PACKER } }),
  ]);

  await prisma.companyProfile.create({ data: { name: "PT Seller Nusantara Digital", taxId: "09.876.543.2-001.000", email: "ops@sellernusantara.id", phone: "+62 812-9000-1122", address: "Jl. Kemandoran Raya No. 18, Jakarta Selatan" } });

  const warehouseData = [
    { code: "JKT", name: "Gudang Jakarta", city: "Jakarta Selatan", province: "DKI Jakarta", address: "Jl. Kemandoran Raya No. 18", isPrimary: true },
    { code: "BDG", name: "Gudang Bandung", city: "Bandung", province: "Jawa Barat", address: "Jl. Soekarno Hatta No. 90", isPrimary: false },
    { code: "SBY", name: "Gudang Surabaya", city: "Surabaya", province: "Jawa Timur", address: "Jl. Rungkut Industri No. 4", isPrimary: false },
  ];
  const warehouses = [] as any[];
  const locations = [] as any[];
  for (const wh of warehouseData) {
    const warehouse = await prisma.warehouse.create({ data: wh });
    warehouses.push(warehouse);
    for (const zone of ["A", "B", "C"]) {
      for (let i = 1; i <= 6; i++) {
        const loc = await prisma.location.create({ data: { warehouseId: warehouse.id, code: `${zone}-${String(i).padStart(2, "0")}-R1-B1`, zone, aisle: String(i).padStart(2, "0"), rack: "R1", bin: "B1", capacity: rand(80, 240) } });
        locations.push(loc);
      }
    }
  }

  const categories = ["Fashion", "Beauty", "Elektronik", "Rumah Tangga", "F&B", "Aksesoris", "Kesehatan"];
  const productNames = [
    "Kaos Basic Cotton Premium", "Hoodie Oversize Fleece", "Celana Jogger Unisex", "Kemeja Linen Casual", "Dress Midi Floral", "Hijab Voal Premium", "Sandal Rumah Anti Slip", "Tas Selempang Mini",
    "Serum Niacinamide 10%", "Sunscreen Gel SPF 50", "Lip Tint Matte", "Facial Wash Gentle", "Moisturizer Ceramide", "Body Lotion Brightening", "Hair Tonic Herbal", "Masker Wajah Clay",
    "Lampu LED Meja USB", "Kabel Type-C Fast Charge", "Powerbank 10000mAh", "Tripod HP Portable", "Mouse Wireless Silent", "Keyboard Bluetooth Mini", "Earphone Bass Pro", "Stand Laptop Foldable",
    "Botol Minum Stainless", "Rak Dapur Serbaguna", "Vacuum Bag Organizer", "Lap Microfiber Premium", "Keset Anti Slip", "Gantungan Baju Stainless", "Kotak Penyimpanan Lipat", "Sikat Botol 3in1",
    "Kopi Arabika Drip Bag", "Teh Rosella Organik", "Granola Cokelat Almond", "Sambal Bawang Botol", "Keripik Pisang Cokelat", "Madu Hutan Asli", "Bumbu Rendang Instan", "Abon Sapi Premium",
    "Case HP Transparan", "Tempered Glass 9H", "Dompet Kartu RFID", "Tali Masker Manik", "Topi Baseball Polos", "Kacamata Anti Radiasi", "Jam Tangan Digital", "Payung Lipat Otomatis",
    "Minyak Kayu Putih", "Vitamin C Effervescent", "Hand Sanitizer Spray", "Plester Luka Waterproof", "Kompres Gel Dingin", "Masker Medis 3 Ply", "Timbangan Badan Digital", "Bantal Leher Travel"
  ];

  const variants: any[] = [];
  for (let i = 0; i < productNames.length; i++) {
    const name = productNames[i];
    const sku = `PRD-${String(i + 1).padStart(4, "0")}`;
    const product = await prisma.product.create({
      data: { sku, name, slug: slugify(`${sku}-${name}`), description: `${name} siap jual di marketplace Indonesia dengan kemasan aman untuk fulfillment gudang.`, brand: pick(["NusaStore", "GudangKita", "Arunika", "LokalPro"]), category: categories[i % categories.length], weightGram: rand(80, 1200), lengthCm: rand(8, 35), widthCm: rand(6, 28), heightCm: rand(3, 18), lowStockThreshold: rand(8, 18), reorderPoint: rand(20, 45) },
    });
    const attrs = i % 3 === 0 ? ["Hitam", "Putih"] : i % 3 === 1 ? ["S", "M", "L"] : ["Reguler"];
    for (let j = 0; j < attrs.length; j++) {
      const vSku = `${sku}-${String(j + 1).padStart(2, "0")}`;
      const barcode = `899${String(1000000000 + i * 10 + j).slice(0, 10)}`;
      const qrCode = await QRCode.toDataURL(vSku);
      const variant = await prisma.variant.create({ data: { productId: product.id, sku: vSku, name: attrs[j], color: ["Hitam", "Putih"].includes(attrs[j]) ? attrs[j] : undefined, size: ["S", "M", "L"].includes(attrs[j]) ? attrs[j] : undefined, barcode, qrCode, costPrice: rand(12000, 120000), sellPrice: rand(29000, 249000) } });
      variants.push({ ...variant, product });
      for (const wh of warehouses) {
        const loc = pick(locations.filter((l) => l.warehouseId === wh.id));
        const qty = rand(4, 160);
        await prisma.stock.create({ data: { variantId: variant.id, warehouseId: wh.id, locationId: loc.id, quantity: qty, reserved: rand(0, Math.min(8, qty)) } });
        await prisma.stockMovement.create({ data: { variantId: variant.id, warehouseId: wh.id, locationId: loc.id, type: "RECEIVING", quantity: qty, beforeQty: 0, afterQty: qty, note: "Saldo awal seed data" } });
      }
    }
  }

  const accounts = await Promise.all([
    prisma.marketplaceAccount.create({ data: { marketplace: Marketplace.SHOPEE, shopName: "NusaStore Official Shopee", shopId: "SHP-102938", apiKey: "PLACEHOLDER", apiSecret: "PLACEHOLDER", syncInterval: 10 } }),
    prisma.marketplaceAccount.create({ data: { marketplace: Marketplace.TIKTOK_SHOP, shopName: "NusaStore TikTok Shop", shopId: "TTS-203948", apiKey: "PLACEHOLDER", apiSecret: "PLACEHOLDER", syncInterval: 5 } }),
    prisma.marketplaceAccount.create({ data: { marketplace: Marketplace.LAZADA, shopName: "NusaStore Lazada", shopId: "LZD-309485", apiKey: "PLACEHOLDER", apiSecret: "PLACEHOLDER", syncInterval: 15 } }),
    prisma.marketplaceAccount.create({ data: { marketplace: Marketplace.TOKOPEDIA, shopName: "NusaStore Tokopedia", shopId: "TKP-405867", apiKey: "PLACEHOLDER", apiSecret: "PLACEHOLDER", syncInterval: 10 } }),
  ]);
  for (const acc of accounts) {
    for (const v of variants.slice(0, 80)) {
      await prisma.marketplaceListing.create({ data: { marketplaceAccountId: acc.id, productId: v.productId, variantId: v.id, externalProductId: `${acc.marketplace}-${v.product.sku}`, externalVariantId: `${acc.marketplace}-${v.sku}`, title: `${v.product.name} ${v.name}`, price: v.sellPrice, commissionRate: acc.marketplace === "SHOPEE" ? 4.25 : acc.marketplace === "TIKTOK_SHOP" ? 5.5 : 4.75, feeRate: 1.8, status: "ACTIVE", stockSyncedAt: new Date() } });
    }
  }

  const customers = ["Ayu Lestari", "Budi Santoso", "Citra Maharani", "Dewi Anggraini", "Eko Prasetyo", "Fitri Handayani", "Gilang Saputra", "Hana Nuraini", "Indra Wijaya", "Joko Susilo", "Kartika Putri", "Lina Marlina", "Maya Sari", "Naufal Hakim", "Oki Ramadhan", "Putri Anjani", "Rizky Hidayat", "Salsa Amelia", "Tono Wibowo", "Yuni Astuti"];
  const cities = [
    ["Jakarta Selatan", "DKI Jakarta"], ["Jakarta Barat", "DKI Jakarta"], ["Bandung", "Jawa Barat"], ["Bekasi", "Jawa Barat"], ["Surabaya", "Jawa Timur"], ["Sidoarjo", "Jawa Timur"], ["Semarang", "Jawa Tengah"], ["Yogyakarta", "DI Yogyakarta"], ["Denpasar", "Bali"], ["Medan", "Sumatera Utara"]
  ];
  const statusList: OrderStatus[] = ["NEW", "CONFIRMED", "PICKING", "PACKING", "READY_TO_SHIP", "SHIPPED", "DELIVERED", "COMPLETED", "RETURNED"];
  const couriers = ["JNE", "J&T", "SiCepat", "Anteraja", "Ninja", "ID Express"];
  for (let i = 1; i <= 210; i++) {
    const account = pick(accounts);
    const wh = pick(warehouses);
    const [city, province] = pick(cities);
    const itemCount = rand(1, 4);
    const chosen = Array.from({ length: itemCount }, () => pick(variants));
    const items = chosen.map((v) => ({ variant: v, qty: rand(1, 3), price: Number(v.sellPrice) }));
    const subtotal = items.reduce((a, x) => a + x.qty * x.price, 0);
    const shippingFee = subtotal > 300000 ? 0 : rand(9000, 32000);
    const commission = Math.round(subtotal * 0.045);
    const marketplaceFee = Math.round(subtotal * 0.018);
    const discount = rand(0, 1) ? rand(5000, 25000) : 0;
    const status = pick(statusList);
    const daysAgo = rand(0, 45);
    const orderedAt = new Date(Date.now() - daysAgo * 24 * 3600 * 1000 - rand(0, 18) * 3600 * 1000);
    const order = await prisma.order.create({
      data: {
        orderNo: `ORD-${orderedAt.toISOString().slice(0, 10).replaceAll("-", "")}-${String(i).padStart(5, "0")}`,
        marketplaceOrderId: `${account.marketplace}-${100000 + i}`,
        marketplaceAccountId: account.id,
        warehouseId: wh.id,
        marketplace: account.marketplace,
        status,
        priority: i % 17 === 0 ? OrderPriority.URGENT : i % 7 === 0 ? OrderPriority.HIGH : OrderPriority.NORMAL,
        customerName: pick(customers), customerPhone: `08${rand(1111111111, 9999999999)}`,
        address: `Jl. ${pick(["Melati", "Kenanga", "Merdeka", "Sudirman", "Diponegoro", "Cempaka"])} No. ${rand(1, 180)}, RT ${rand(1, 9)}/RW ${rand(1, 12)}`,
        province, city, district: pick(["Kecamatan Tengah", "Kecamatan Barat", "Kecamatan Timur", "Kecamatan Selatan"]), postalCode: String(rand(10000, 89999)), buyerNote: i % 9 === 0 ? "Tolong packing tebal, untuk hadiah." : undefined,
        subtotal, shippingFee, marketplaceFee, commissionFee: commission, discount, grandTotal: subtotal + shippingFee + marketplaceFee + commission - discount,
        courier: ["SHIPPED", "DELIVERED", "COMPLETED"].includes(status) ? pick(couriers) : undefined,
        service: ["SHIPPED", "DELIVERED", "COMPLETED"].includes(status) ? pick(["REG", "EZ", "BEST", "YES"]) : undefined,
        trackingNumber: ["SHIPPED", "DELIVERED", "COMPLETED"].includes(status) ? `${pick(couriers).replace(/[^A-Z]/g, "")}${rand(100000000000, 999999999999)}` : undefined,
        paymentMethod: pick(["COD", "Transfer", "ShopeePay", "OVO", "GoPay", "Kartu Kredit"]), orderedAt,
        shippedAt: ["SHIPPED", "DELIVERED", "COMPLETED"].includes(status) ? new Date(orderedAt.getTime() + 24 * 3600 * 1000) : undefined,
        deliveredAt: ["DELIVERED", "COMPLETED"].includes(status) ? new Date(orderedAt.getTime() + 3 * 24 * 3600 * 1000) : undefined,
        items: { create: items.map((x) => ({ productId: x.variant.productId, variantId: x.variant.id, sku: x.variant.sku, name: `${x.variant.product.name} ${x.variant.name}`, qty: x.qty, price: x.price, total: x.qty * x.price })) },
      },
    });
    if (["PICKING", "PACKING", "READY_TO_SHIP"].includes(status)) {
      const pickTask = await prisma.pickTask.create({ data: { orderId: order.id, warehouseId: wh.id, assignedToId: users[3].id, status: status === "PICKING" ? "IN_PROGRESS" : "DONE", startedAt: orderedAt, completedAt: status === "PICKING" ? undefined : new Date(orderedAt.getTime() + 2 * 3600 * 1000), items: { create: items.map((x) => ({ variantId: x.variant.id, sku: x.variant.sku, qtyRequired: x.qty, qtyPicked: status === "PICKING" ? 0 : x.qty, location: "AUTO-BIN" })) } } });
      if (["PACKING", "READY_TO_SHIP"].includes(status)) await prisma.packingTask.create({ data: { orderId: order.id, warehouseId: wh.id, assignedToId: users[4].id, status: status === "PACKING" ? "IN_PROGRESS" : "DONE", items: { create: items.map((x) => ({ variantId: x.variant.id, sku: x.variant.sku, qtyRequired: x.qty, qtyVerified: status === "PACKING" ? 0 : x.qty })) } } });
      void pickTask;
    }
  }

  await prisma.receivingNote.create({ data: { number: "RCV-20260503-0001", warehouseId: warehouses[0].id, supplier: "PT Distributor Lokal Jaya", status: "TODO", note: "PO refill produk best seller", items: { create: variants.slice(0, 8).map((v) => ({ variantId: v.id, expectedQty: rand(20, 80), locationCode: "A-01-R1-B1" })) } } });
  await prisma.shippingRule.createMany({ data: [
    { name: "Gratis Ongkir > Rp300.000", minOrderValue: 300000, freeShipping: true, maxDiscount: 25000, isActive: true },
    { name: "Prioritas JNE REG Jakarta", courier: "JNE", service: "REG", isActive: true },
    { name: "COD via J&T dan SiCepat", courier: "J&T", service: "EZ", isActive: true },
  ] });
  await prisma.notification.createMany({ data: [
    { title: "Stok SKU menipis", message: "12 SKU berada di bawah reorder point. Cek halaman Inventory.", level: "WARNING", module: "inventory" },
    { title: "Order urgent belum dipick", message: "Ada order prioritas URGENT dari TikTok Shop yang belum masuk picking.", level: "ERROR", module: "orders" },
    { title: "Sync marketplace berhasil", message: "Shopee, Lazada, TikTok Shop, dan Tokopedia tersinkron 10 menit lalu.", level: "SUCCESS", module: "marketplace" },
    { title: "Pengiriman terlambat", message: "5 order melewati SLA packing 24 jam.", level: "WARNING", module: "warehouse" },
  ] });
  await prisma.appSetting.createMany({ data: [
    { key: "locale", value: { primary: "id-ID", fallback: "en-US" } },
    { key: "invoice", value: { ppnRate: 11, prefix: "INV", template: "default" } },
    { key: "keyboardShortcuts", value: { globalSearch: "Ctrl+K", sync: "Ctrl+Shift+S", pickScan: "Ctrl+Shift+P" } },
  ] });
  console.log("Seed selesai: 5 user, 3 warehouse, 56 produk, 200+ order, marketplace account, task, dan notifikasi.");
}

main().finally(async () => prisma.$disconnect());
