# Arsitektur WMS Pro Indonesia

## Modul Utama

1. **Dashboard**: KPI realtime, sales trend, distribusi marketplace, inventory turnover, notifikasi operasional.
2. **Inventory**: master produk, varian SKU, barcode/QR, multi-warehouse, bin/rak, stock movement audit trail, low stock, reorder point.
3. **Marketplace Integration**: Shopee, TikTok Shop, Lazada, Tokopedia. Implementasi awal memakai adapter mock yang mengikuti kontrak `MarketplaceAdapter`.
4. **Order Management**: unified inbox, status flow `NEW → CONFIRMED → PICKING → PACKING → READY_TO_SHIP → SHIPPED → DELIVERED → COMPLETED/RETURNED`.
5. **Warehouse Operations**: receiving, putaway, picking, packing, shipping, returns.
6. **Shipping & Logistics**: provider mock Indonesia, quote ongkir, create shipment, tracking, shipping label endpoint siap dikembangkan.
7. **Reporting**: export CSV, Excel, PDF untuk sales, inventory, dan operasional.
8. **User Management & RBAC**: NextAuth v5 credentials, role Owner, Manager, Warehouse Staff, Picker, Packer, Viewer.
9. **Settings**: company profile, warehouse, marketplace API key, courier rules, notification, invoice/tax.

## ERD Ringkas

- `User` memiliki `Role` dan menghasilkan `ActivityLog`.
- `Warehouse` memiliki banyak `Location`, `Stock`, `ReceivingNote`, `PickTask`, `PackingTask`, dan `Order`.
- `Product` memiliki banyak `Variant`; `Variant` memiliki banyak `Stock` per warehouse/location.
- `StockMovement` menjadi audit trail semua perubahan stok.
- `MarketplaceAccount` memiliki banyak `MarketplaceListing` dan `Order`.
- `Order` memiliki banyak `OrderItem`, `PickTask`, `PackingTask`, `Shipment`, dan `ReturnOrder`.
- `ReceivingNote` dan `ReceivingItem` mencatat inbound stock.
- `ShippingRule`, `AppSetting`, dan `Notification` mendukung konfigurasi operasional.

## Realtime

Gunakan Supabase Realtime pada channel:

- `wms-stock` untuk perubahan stok dan low-stock alert.
- `wms-orders` untuk order baru dan perubahan status.
- `wms-notifications` untuk alert operasional.

Untuk production, aktifkan Postgres publication di Supabase untuk tabel `Stock`, `Order`, dan `Notification`, lalu subscribe dari komponen client.

## Security Baseline

- Simpan secret marketplace dan kurir hanya di server-side environment variable atau encrypted vault.
- Terapkan RBAC di middleware/API handler sebelum write action.
- Aktifkan rate limiting untuk route sync dan import.
- Simpan activity log untuk perubahan status order, stock adjustment, import, dan sync.
- Validasi payload memakai Zod.
