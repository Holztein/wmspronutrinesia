# Catatan Integrasi API Marketplace & Kurir

## Marketplace

### Shopee Open Platform

- Gunakan OAuth/seller authorization untuk mendapatkan `access_token`, `refresh_token`, dan `shop_id`.
- Order sync: pull order detail, lalu normalisasi ke model `Order` dan `OrderItem`.
- Inventory sync: push stok per item/varian dari total available stock WMS.
- Shipping update: kirim status dan resi sesuai endpoint shipping/order Shopee.
- Implementasi production ditempatkan di `src/lib/marketplaces/adapters.ts` menggantikan `MockAdapter`.

### TikTok Shop / Tokopedia Shop Open API

- Gunakan Partner Center onboarding untuk ISV/Seller Developer.
- Normalisasi status order ke enum internal WMS.
- Simpan token per shop pada `MarketplaceAccount`.
- Jadwalkan sync order 5 menit untuk toko aktif.

### Lazada Open Platform

- Gunakan OAuth2 seller authorization untuk access token.
- Lazada menyediakan modul Seller API, Product API, Order API, Finance API, dan API terkait listing.
- Push inventory perlu menjaga mapping `externalProductId` dan `externalVariantId` pada `MarketplaceListing`.

### Tokopedia

- Akses API seller biasanya memerlukan onboarding partner/resmi.
- Bila akses langsung belum tersedia, integrasi dapat dilakukan melalui agregator resmi atau middleware internal yang sudah disetujui.

## Kurir / Ongkir

### RajaOngkir / Komerce

- Cocok untuk kalkulasi ongkir, tracking, dan delivery order API.
- Simpan area/origin mapping per warehouse.
- Endpoint quote diganti pada `src/lib/logistics/providers.ts`.

### Komship

- Cocok untuk create order, tarif, dan pickup courier.
- Mapping courier/service internal tetap dipertahankan agar UI tidak berubah.

### Shipper

- API memakai header `X-API-Key` dan mendukung pricing, shipment, tracking, serta webhook.
- Webhook status shipment dapat memperbarui `Shipment.status` dan `Order.status`.

### JNE

- JNE memiliki dashboard API resmi; akses biasanya melalui kerja sama/registrasi.
- Alternatif production: aggregator seperti Shipper, Biteship, KiriminAja, atau Komship sesuai kontrak bisnis.

## Webhook Production

Buat endpoint:

- `/api/webhooks/shopee`
- `/api/webhooks/tiktok-shop`
- `/api/webhooks/lazada`
- `/api/webhooks/logistics`

Validasi signature, simpan raw payload, proses idempotent berdasarkan external event id, lalu update order/stock/shipment.
