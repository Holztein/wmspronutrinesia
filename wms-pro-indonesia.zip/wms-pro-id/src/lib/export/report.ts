import { jsPDF } from "jspdf";
import * as XLSX from "xlsx";

export function ordersToXlsx(rows: Record<string, unknown>[]) {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.json_to_sheet(rows);
  XLSX.utils.book_append_sheet(wb, ws, "Laporan Pesanan");
  return XLSX.write(wb, { type: "buffer", bookType: "xlsx" });
}

export function simplePdf(title: string, lines: string[]) {
  const doc = new jsPDF();
  doc.setFontSize(16);
  doc.text(title, 14, 18);
  doc.setFontSize(10);
  lines.forEach((line, i) => doc.text(line, 14, 32 + i * 7));
  return Buffer.from(doc.output("arraybuffer"));
}
