export type ShippingQuoteRequest = {
  origin: string;
  destination: string;
  weightGram: number;
  itemValue: number;
  courier?: string;
};
export type ShippingQuote = { courier: string; service: string; etd: string; cost: number; cod: boolean };
export interface LogisticsProvider {
  quote(input: ShippingQuoteRequest): Promise<ShippingQuote[]>;
  createShipment(input: { orderNo: string; courier: string; service: string; destination: string; weightGram: number }): Promise<{ trackingNumber: string; labelUrl?: string; raw: unknown }>;
  track(trackingNumber: string): Promise<{ status: string; history: { time: string; note: string }[] }>;
}
