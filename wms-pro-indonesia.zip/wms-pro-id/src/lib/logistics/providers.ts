import type { LogisticsProvider, ShippingQuote, ShippingQuoteRequest } from "./types";

export class MockIndonesiaLogisticsProvider implements LogisticsProvider {
  async quote(input: ShippingQuoteRequest): Promise<ShippingQuote[]> {
    const base = Math.max(9000, Math.ceil(input.weightGram / 1000) * 11000);
    return [
      { courier: input.courier ?? "JNE", service: "REG", etd: "2-3 hari", cost: input.itemValue > 300000 ? 0 : base, cod: true },
      { courier: "J&T", service: "EZ", etd: "1-2 hari", cost: input.itemValue > 300000 ? 0 : base + 1500, cod: true },
      { courier: "SiCepat", service: "BEST", etd: "1 hari", cost: base + 6000, cod: false },
      { courier: "Anteraja", service: "REG", etd: "2-4 hari", cost: base - 1000, cod: true },
    ];
  }
  async createShipment(input: { orderNo: string; courier: string; service: string }) {
    return { trackingNumber: `${input.courier.toUpperCase().replace(/[^A-Z]/g, "")}${Date.now()}`, labelUrl: `/api/warehouse/shipping/label?order=${input.orderNo}`, raw: { mode: "mock", service: input.service } };
  }
  async track(trackingNumber: string) {
    return { status: "IN_TRANSIT", history: [{ time: new Date().toISOString(), note: `Resi ${trackingNumber} sedang diproses kurir.` }] };
  }
}

export const logisticsProvider = new MockIndonesiaLogisticsProvider();
