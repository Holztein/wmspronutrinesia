import { z } from "zod";

export const inventoryQuerySchema = z.object({
  q: z.string().optional(),
  warehouseId: z.string().optional(),
  lowStock: z.coerce.boolean().optional(),
  page: z.coerce.number().min(1).default(1),
  limit: z.coerce.number().min(1).max(100).default(20),
});

export const stockAdjustmentSchema = z.object({
  variantId: z.string().min(1),
  warehouseId: z.string().min(1),
  locationId: z.string().optional(),
  quantity: z.number().int(),
  note: z.string().optional(),
});

export const orderStatusSchema = z.object({
  orderIds: z.array(z.string()).min(1),
  status: z.enum(["NEW", "CONFIRMED", "PICKING", "PACKING", "READY_TO_SHIP", "SHIPPED", "DELIVERED", "COMPLETED", "RETURNED", "CANCELLED"]),
  warehouseId: z.string().optional(),
});

export const receivingSchema = z.object({
  warehouseId: z.string(),
  supplier: z.string().min(2),
  items: z.array(z.object({ variantId: z.string(), expectedQty: z.number().int().positive(), receivedQty: z.number().int().nonnegative(), locationCode: z.string().optional() })).min(1),
  note: z.string().optional(),
});

export const shippingQuoteSchema = z.object({
  orderId: z.string(),
  courier: z.string().optional(),
  service: z.string().optional(),
});
