import { createClient } from "@supabase/supabase-js";

export function createRealtimeClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anon = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anon) return null;
  return createClient(url, anon, { realtime: { params: { eventsPerSecond: 8 } } });
}

export const realtimeChannels = {
  stock: "wms-stock",
  orders: "wms-orders",
  notifications: "wms-notifications",
};
