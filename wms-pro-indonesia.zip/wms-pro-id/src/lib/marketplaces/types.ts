import { Marketplace, OrderStatus } from "@prisma/client";

export type MarketplaceCredential = {
  shopId: string;
  apiKey?: string | null;
  apiSecret?: string | null;
  accessToken?: string | null;
  refreshToken?: string | null;
};

export type MarketplaceOrder = {
  marketplace: Marketplace;
  externalOrderId: string;
  status: OrderStatus;
  customerName: string;
  address: string;
  city: string;
  province: string;
  total: number;
  items: { sku: string; qty: number; price: number }[];
};

export interface MarketplaceAdapter {
  pullOrders(credential: MarketplaceCredential): Promise<MarketplaceOrder[]>;
  pushInventory(credential: MarketplaceCredential, items: { externalProductId: string; externalVariantId?: string | null; sku: string; stock: number }[]): Promise<{ ok: boolean; message: string }>;
  updateOrderStatus(credential: MarketplaceCredential, externalOrderId: string, status: OrderStatus, trackingNumber?: string): Promise<{ ok: boolean; message: string }>;
}
