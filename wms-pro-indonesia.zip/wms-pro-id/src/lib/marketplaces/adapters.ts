import { Marketplace, OrderStatus } from "@prisma/client";
import type { MarketplaceAdapter, MarketplaceCredential, MarketplaceOrder } from "./types";

function mockOrders(marketplace: Marketplace, shopId: string): MarketplaceOrder[] {
  return Array.from({ length: 3 }).map((_, idx) => ({
    marketplace,
    externalOrderId: `${marketplace}-${shopId}-${Date.now()}-${idx}`,
    status: "NEW" as OrderStatus,
    customerName: ["Rina Amelia", "Budi Santoso", "Siti Rahma"][idx],
    address: ["Jl. Tebet Timur Raya No. 12", "Jl. Buah Batu No. 88", "Jl. Manyar Kertoarjo No. 7"][idx],
    city: ["Jakarta Selatan", "Bandung", "Surabaya"][idx],
    province: ["DKI Jakarta", "Jawa Barat", "Jawa Timur"][idx],
    total: [189000, 329000, 76000][idx],
    items: [{ sku: `SKU-MOCK-${idx + 1}`, qty: idx + 1, price: [63000, 164500, 76000][idx] }],
  }));
}

class MockAdapter implements MarketplaceAdapter {
  constructor(private marketplace: Marketplace) {}
  async pullOrders(credential: MarketplaceCredential) { return mockOrders(this.marketplace, credential.shopId); }
  async pushInventory(_: MarketplaceCredential, items: { sku: string; stock: number }[]) { return { ok: true, message: `Mock sync ${items.length} SKU berhasil.` }; }
  async updateOrderStatus(_: MarketplaceCredential, externalOrderId: string) { return { ok: true, message: `Mock status order ${externalOrderId} diperbarui.` }; }
}

export function getMarketplaceAdapter(marketplace: Marketplace): MarketplaceAdapter {
  // Ganti MockAdapter dengan client resmi masing-masing marketplace.
  // Shopee: HMAC signature partner_id, timestamp, access_token, shop_id.
  // TikTok Shop: app_key + sign + access token.
  // Lazada: OAuth access token + signed REST request.
  // Tokopedia: seller partner access sesuai onboarding resmi.
  return new MockAdapter(marketplace);
}
