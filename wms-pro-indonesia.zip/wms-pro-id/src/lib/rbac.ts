import { Role } from "@prisma/client";

export type Permission =
  | "dashboard:read"
  | "inventory:read" | "inventory:write" | "inventory:sync"
  | "orders:read" | "orders:write" | "orders:ship"
  | "warehouse:receive" | "warehouse:pick" | "warehouse:pack" | "warehouse:ship"
  | "reports:read" | "settings:write" | "users:manage";

export const rolePermissions: Record<Role, Permission[]> = {
  OWNER: ["dashboard:read", "inventory:read", "inventory:write", "inventory:sync", "orders:read", "orders:write", "orders:ship", "warehouse:receive", "warehouse:pick", "warehouse:pack", "warehouse:ship", "reports:read", "settings:write", "users:manage"],
  MANAGER: ["dashboard:read", "inventory:read", "inventory:write", "inventory:sync", "orders:read", "orders:write", "orders:ship", "warehouse:receive", "warehouse:pick", "warehouse:pack", "warehouse:ship", "reports:read"],
  WAREHOUSE_STAFF: ["dashboard:read", "inventory:read", "orders:read", "warehouse:receive", "warehouse:pick", "warehouse:pack", "warehouse:ship"],
  PICKER: ["inventory:read", "orders:read", "warehouse:pick"],
  PACKER: ["inventory:read", "orders:read", "warehouse:pack", "warehouse:ship"],
  VIEWER: ["dashboard:read", "inventory:read", "orders:read", "reports:read"],
};

export function can(role: Role | undefined, permission: Permission) {
  if (!role) return false;
  return rolePermissions[role]?.includes(permission) ?? false;
}
