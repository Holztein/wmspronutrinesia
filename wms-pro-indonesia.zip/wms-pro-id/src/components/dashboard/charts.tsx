"use client";

import { Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { rupiah } from "@/lib/utils";

export function SalesTrendChart({ data }: { data: { date: string; sales: number; orders: number }[] }) {
  return (
    <Card className="col-span-1 lg:col-span-2">
      <CardHeader><CardTitle>Tren Penjualan 7 Hari</CardTitle></CardHeader>
      <CardContent className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
            <XAxis dataKey="date" fontSize={12} />
            <YAxis fontSize={12} tickFormatter={(v) => `${Math.round(Number(v) / 1000)}rb`} />
            <Tooltip formatter={(v, n) => n === "sales" ? rupiah.format(Number(v)) : v} />
            <Area type="monotone" dataKey="sales" stroke="currentColor" fill="currentColor" fillOpacity={0.12} />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function MarketplacePie({ data }: { data: { name: string; value: number }[] }) {
  return (
    <Card>
      <CardHeader><CardTitle>Distribusi Marketplace</CardTitle></CardHeader>
      <CardContent className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie dataKey="value" nameKey="name" data={data} innerRadius={58} outerRadius={92} paddingAngle={2}>
              {data.map((_, i) => <Cell key={i} />)}
            </Pie>
            <Tooltip />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function TurnoverBar({ data }: { data: { category: string; turnover: number }[] }) {
  return (
    <Card className="col-span-1 lg:col-span-3">
      <CardHeader><CardTitle>Inventory Turnover per Kategori</CardTitle></CardHeader>
      <CardContent className="h-72">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.25} />
            <XAxis dataKey="category" fontSize={12} />
            <YAxis fontSize={12} />
            <Tooltip />
            <Bar dataKey="turnover" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
