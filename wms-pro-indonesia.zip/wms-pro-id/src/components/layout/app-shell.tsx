import * as React from "react";
import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { MobileNav } from "@/components/layout/mobile-nav";

export function AppShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen warehouse-grid">
      <Sidebar />
      <Topbar />
      <main className="p-4 pb-24 lg:ml-72 lg:p-6">{children}</main>
      <MobileNav />
    </div>
  );
}
