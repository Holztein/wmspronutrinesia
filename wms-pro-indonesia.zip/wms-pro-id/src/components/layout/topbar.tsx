"use client";

import { Bell, Command, Moon, Search, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SignOutButton } from "@/components/layout/sign-out-button";
import { useEffect, useState } from "react";

export function Topbar() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const isDark = localStorage.getItem("theme") === "dark";
    setDark(isDark);
    document.documentElement.classList.toggle("dark", isDark);
  }, []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    localStorage.setItem("theme", next ? "dark" : "light");
    document.documentElement.classList.toggle("dark", next);
  };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        document.getElementById("global-search")?.focus();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-3 border-b bg-background/85 px-4 backdrop-blur lg:ml-72 lg:px-6">
      <div className="relative max-w-2xl flex-1">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input id="global-search" placeholder="Cari SKU, pesanan, customer, resi..." className="pl-9 pr-16" />
        <div className="absolute right-2 top-2 hidden items-center gap-1 rounded border px-1.5 py-0.5 text-xs text-muted-foreground md:flex"><Command className="h-3 w-3" />K</div>
      </div>
      <Button variant="outline" size="icon" onClick={toggle} aria-label="Ganti tema">{dark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}</Button>
      <Button variant="outline" size="icon" aria-label="Notifikasi"><Bell className="h-4 w-4" /></Button>
      <SignOutButton />
    </header>
  );
}
