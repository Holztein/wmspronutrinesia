"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BarChart3, Boxes, ClipboardList, LayoutDashboard, Settings, Truck, Warehouse } from "lucide-react";
import { cn } from "@/lib/utils";

const nav = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/inventory", label: "Inventory", icon: Boxes },
  { href: "/orders", label: "Pesanan", icon: ClipboardList },
  { href: "/warehouse", label: "Operasional Gudang", icon: Warehouse },
  { href: "/reports", label: "Laporan", icon: BarChart3 },
  { href: "/settings", label: "Pengaturan", icon: Settings },
];

export function Sidebar() {
  const pathname = usePathname();
  return (
    <aside className="hidden border-r bg-card/75 backdrop-blur lg:fixed lg:inset-y-0 lg:left-0 lg:z-40 lg:flex lg:w-72 lg:flex-col">
      <div className="flex h-16 items-center gap-3 border-b px-6">
        <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-primary text-primary-foreground"><Truck className="h-5 w-5" /></div>
        <div>
          <div className="font-bold">WMS Pro ID</div>
          <div className="text-xs text-muted-foreground">Multi-Marketplace</div>
        </div>
      </div>
      <nav className="flex-1 space-y-1 p-4">
        {nav.map((item) => {
          const active = pathname === item.href;
          return (
            <Link key={item.href} href={item.href} className={cn("flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-muted-foreground transition hover:bg-accent hover:text-foreground", active && "bg-primary/10 text-primary") }>
              <item.icon className="h-5 w-5" /> {item.label}
            </Link>
          );
        })}
      </nav>
      <div className="m-4 rounded-2xl border bg-gradient-to-br from-primary/10 to-orange-500/5 p-4 text-sm">
        <p className="font-semibold">Mode Warehouse</p>
        <p className="mt-1 text-muted-foreground">Scan barcode, picking, packing, dan shipping siap dipakai di HP/tablet.</p>
      </div>
    </aside>
  );
}
