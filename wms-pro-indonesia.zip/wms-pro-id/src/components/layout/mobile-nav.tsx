"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Boxes, ClipboardList, LayoutDashboard, Warehouse } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { href: "/", label: "Home", icon: LayoutDashboard },
  { href: "/inventory", label: "Stok", icon: Boxes },
  { href: "/orders", label: "Order", icon: ClipboardList },
  { href: "/warehouse", label: "Gudang", icon: Warehouse },
];
export function MobileNav() {
  const pathname = usePathname();
  return <nav className="fixed inset-x-0 bottom-0 z-50 grid grid-cols-4 border-t bg-background/95 p-1 backdrop-blur lg:hidden">{items.map((x) => <Link key={x.href} href={x.href} className={cn("flex flex-col items-center gap-1 rounded-xl py-2 text-xs text-muted-foreground", pathname === x.href && "bg-primary/10 text-primary")}><x.icon className="h-5 w-5" />{x.label}</Link>)}</nav>;
}
