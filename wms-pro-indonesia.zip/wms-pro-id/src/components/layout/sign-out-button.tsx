"use client";
import { signOut } from "next-auth/react";
import { LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
export function SignOutButton() {
  return <Button variant="outline" size="icon" onClick={() => signOut({ callbackUrl: "/login" })} aria-label="Keluar"><LogOut className="h-4 w-4" /></Button>;
}
