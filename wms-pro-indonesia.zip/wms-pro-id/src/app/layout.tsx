import type { Metadata, Viewport } from "next";
import * as React from "react";
import "./globals.css";
import { PwaRegister } from "@/components/pwa-register";

export const metadata: Metadata = {
  title: "WMS Pro Indonesia",
  description: "Warehouse Management System profesional untuk seller multi-marketplace Indonesia",
  manifest: "/manifest.json",
};

export const viewport: Viewport = { themeColor: "#ea580c" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id" suppressHydrationWarning>
      <body><PwaRegister />{children}</body>
    </html>
  );
}
