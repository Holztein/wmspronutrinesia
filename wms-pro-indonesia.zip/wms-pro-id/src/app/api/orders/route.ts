import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { orderStatusSchema } from "@/lib/validators";

export async function GET(request: NextRequest) {
  const sp = request.nextUrl.searchParams;
  const marketplace = sp.get("marketplace") as any;
  const status = sp.get("status") as any;
  const q = sp.get("q");
  const orders = await prisma.order.findMany({
    where: {
      ...(marketplace ? { marketplace } : {}),
      ...(status ? { status } : {}),
      ...(q ? { OR: [{ orderNo: { contains: q, mode: "insensitive" } }, { customerName: { contains: q, mode: "insensitive" } }, { trackingNumber: { contains: q, mode: "insensitive" } }] } : {}),
    },
    orderBy: { orderedAt: "desc" },
    take: 100,
    include: { items: true, warehouse: true },
  });
  return NextResponse.json({ data: orders });
}

export async function PATCH(request: NextRequest) {
  const body = orderStatusSchema.parse(await request.json());
  const updated = await prisma.order.updateMany({ where: { id: { in: body.orderIds } }, data: { status: body.status, warehouseId: body.warehouseId } });
  await prisma.activityLog.create({ data: { module: "orders", action: "bulk_status_update", metadata: body } });
  return NextResponse.json({ ok: true, updated: updated.count });
}
