import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const [ordersToday, pending, lowStock, sales] = await Promise.all([
    prisma.order.count({ where: { orderedAt: { gte: today } } }),
    prisma.order.count({ where: { status: { in: ["NEW", "CONFIRMED", "PICKING", "PACKING"] } } }),
    prisma.stock.count({ where: { quantity: { lte: 10 } } }),
    prisma.order.aggregate({ where: { orderedAt: { gte: today } }, _sum: { grandTotal: true } }),
  ]);
  return NextResponse.json({ ordersToday, pending, lowStock, salesToday: Number(sales._sum.grandTotal ?? 0) });
}
