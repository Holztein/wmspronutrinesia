import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { shippingQuoteSchema } from "@/lib/validators";
import { logisticsProvider } from "@/lib/logistics/providers";

export async function POST(request: NextRequest) {
  const body = shippingQuoteSchema.parse(await request.json());
  const order = await prisma.order.findUnique({ where: { id: body.orderId }, include: { items: { include: { product: true } } } });
  if (!order) return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  const weightGram = order.items.reduce((sum, item) => sum + item.qty * item.product.weightGram, 0);
  const quotes = await logisticsProvider.quote({ origin: order.warehouseId ?? "JKT", destination: `${order.city}, ${order.province}`, weightGram, itemValue: Number(order.grandTotal), courier: body.courier });
  return NextResponse.json({ ok: true, data: quotes });
}

export async function PATCH(request: NextRequest) {
  const { orderId, courier, service } = await request.json();
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: { include: { product: true } } } });
  if (!order) return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  const weightGram = order.items.reduce((sum, item) => sum + item.qty * item.product.weightGram, 0);
  const shipment = await logisticsProvider.createShipment({ orderNo: order.orderNo, courier, service, destination: `${order.city}, ${order.province}`, weightGram });
  const saved = await prisma.$transaction(async (tx) => {
    const ship = await tx.shipment.create({ data: { orderId, courier, service, trackingNumber: shipment.trackingNumber, labelUrl: shipment.labelUrl, cost: 0, rawResponse: shipment.raw as any } });
    await tx.order.update({ where: { id: orderId }, data: { status: "SHIPPED", shippedAt: new Date(), courier, service, trackingNumber: shipment.trackingNumber } });
    return ship;
  });
  return NextResponse.json({ ok: true, data: saved });
}
