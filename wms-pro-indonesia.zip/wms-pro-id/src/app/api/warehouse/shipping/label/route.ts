import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { simplePdf } from "@/lib/export/report";

export async function GET(request: NextRequest) {
  const orderNo = request.nextUrl.searchParams.get("order");
  if (!orderNo) return NextResponse.json({ error: "Parameter order wajib diisi" }, { status: 400 });
  const order = await prisma.order.findUnique({ where: { orderNo }, include: { items: true, warehouse: true } });
  if (!order) return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  const lines = [
    `ORDER: ${order.orderNo}`,
    `PENERIMA: ${order.customerName}`,
    `ALAMAT: ${order.address}, ${order.district}, ${order.city}, ${order.province}`,
    `KURIR: ${order.courier ?? "-"} ${order.service ?? ""}`,
    `RESI: ${order.trackingNumber ?? "BELUM ADA"}`,
    `GUDANG: ${order.warehouse?.name ?? "-"}`,
    `ITEM: ${order.items.reduce((sum, item) => sum + item.qty, 0)} pcs`,
  ];
  const buffer = simplePdf("LABEL PENGIRIMAN", lines);
  return new NextResponse(buffer, { headers: { "Content-Type": "application/pdf", "Content-Disposition": `inline; filename=label-${order.orderNo}.pdf` } });
}
