import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(request: NextRequest) {
  const { orderId, warehouseId, assignedToId } = await request.json();
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order) return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  const task = await prisma.$transaction(async (tx) => {
    const created = await tx.packingTask.create({
      data: {
        orderId,
        warehouseId,
        assignedToId,
        status: "TODO",
        items: { create: order.items.map((item) => ({ variantId: item.variantId, sku: item.sku, qtyRequired: item.qty })) },
      },
      include: { items: true },
    });
    await tx.order.update({ where: { id: orderId }, data: { status: "PACKING" } });
    return created;
  });
  return NextResponse.json({ ok: true, data: task });
}

export async function PATCH(request: NextRequest) {
  const { packingTaskId, itemId, qtyVerified, photoUrl } = await request.json();
  const item = await prisma.packingTaskItem.update({ where: { id: itemId }, data: { qtyVerified, scannedAt: new Date() } });
  const all = await prisma.packingTaskItem.findMany({ where: { packingTaskId } });
  const done = all.every((x) => x.qtyVerified >= x.qtyRequired);
  if (done) await prisma.packingTask.update({ where: { id: packingTaskId }, data: { status: "DONE", completedAt: new Date(), photoUrl } });
  return NextResponse.json({ ok: true, data: item, done });
}
