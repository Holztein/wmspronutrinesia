import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(request: NextRequest) {
  const { orderId, warehouseId, assignedToId } = await request.json();
  const order = await prisma.order.findUnique({ where: { id: orderId }, include: { items: true } });
  if (!order) return NextResponse.json({ error: "Order tidak ditemukan" }, { status: 404 });
  const task = await prisma.$transaction(async (tx) => {
    const created = await tx.pickTask.create({
      data: {
        orderId,
        warehouseId,
        assignedToId,
        status: "TODO",
        items: { create: order.items.map((item) => ({ variantId: item.variantId, sku: item.sku, qtyRequired: item.qty, location: "AUTO-BIN" })) },
      },
      include: { items: true },
    });
    await tx.order.update({ where: { id: orderId }, data: { status: "PICKING", warehouseId } });
    return created;
  });
  return NextResponse.json({ ok: true, data: task });
}

export async function PATCH(request: NextRequest) {
  const { pickTaskId, itemId, qtyPicked } = await request.json();
  const item = await prisma.pickTaskItem.update({ where: { id: itemId }, data: { qtyPicked, scannedAt: new Date() } });
  const all = await prisma.pickTaskItem.findMany({ where: { pickTaskId } });
  const done = all.every((x) => x.qtyPicked >= x.qtyRequired);
  if (done) await prisma.pickTask.update({ where: { id: pickTaskId }, data: { status: "DONE", completedAt: new Date() } });
  return NextResponse.json({ ok: true, data: item, done });
}
