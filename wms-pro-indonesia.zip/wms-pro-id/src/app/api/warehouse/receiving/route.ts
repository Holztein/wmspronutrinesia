import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { receivingSchema } from "@/lib/validators";

export async function POST(request: NextRequest) {
  const body = receivingSchema.parse(await request.json());
  const number = `RCV-${new Date().toISOString().slice(0, 10).replaceAll("-", "")}-${Math.floor(Math.random() * 9000 + 1000)}`;
  const note = await prisma.$transaction(async (tx) => {
    const receiving = await tx.receivingNote.create({
      data: {
        number,
        warehouseId: body.warehouseId,
        supplier: body.supplier,
        status: "DONE",
        receivedAt: new Date(),
        note: body.note,
        items: { create: body.items },
      },
      include: { items: true },
    });
    for (const item of body.items) {
      const current = await tx.stock.findFirst({ where: { variantId: item.variantId, warehouseId: body.warehouseId } });
      const before = current?.quantity ?? 0;
      const stock = current
        ? await tx.stock.update({ where: { id: current.id }, data: { quantity: { increment: item.receivedQty } } })
        : await tx.stock.create({ data: { variantId: item.variantId, warehouseId: body.warehouseId, quantity: item.receivedQty, reserved: 0 } });
      await tx.stockMovement.create({ data: { variantId: item.variantId, warehouseId: body.warehouseId, type: "RECEIVING", quantity: item.receivedQty, beforeQty: before, afterQty: stock.quantity, referenceType: "receiving", referenceId: receiving.id, note: `Terima barang dari ${body.supplier}` } });
    }
    return receiving;
  });
  return NextResponse.json({ ok: true, data: note });
}
