import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getMarketplaceAdapter } from "@/lib/marketplaces/adapters";

export async function POST(request: NextRequest) {
  const body = await request.json().catch(() => ({}));
  const accounts = await prisma.marketplaceAccount.findMany({ where: { isActive: true, ...(body.accountId ? { id: body.accountId } : {}) } });
  const results = [];
  for (const account of accounts) {
    const adapter = getMarketplaceAdapter(account.marketplace);
    if (body.mode === "inventory") {
      const listings = await prisma.marketplaceListing.findMany({ where: { marketplaceAccountId: account.id }, include: { variant: { include: { stocks: true } } } });
      const items = listings.map((l) => ({ externalProductId: l.externalProductId, externalVariantId: l.externalVariantId, sku: l.variant?.sku ?? l.title, stock: l.variant?.stocks.reduce((a, s) => a + s.quantity - s.reserved, 0) ?? 0 }));
      const result = await adapter.pushInventory(account, items);
      await prisma.marketplaceListing.updateMany({ where: { marketplaceAccountId: account.id }, data: { stockSyncedAt: new Date(), lastError: result.ok ? null : result.message } });
      results.push({ account: account.shopName, mode: "inventory", ...result });
    } else {
      const pulled = await adapter.pullOrders(account);
      await prisma.marketplaceAccount.update({ where: { id: account.id }, data: { lastSyncAt: new Date() } });
      results.push({ account: account.shopName, mode: "orders", count: pulled.length, ok: true });
    }
  }
  await prisma.activityLog.create({ data: { module: "marketplace", action: "sync", metadata: { body, results } } });
  return NextResponse.json({ ok: true, results });
}
