import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { inventoryQuerySchema, stockAdjustmentSchema } from "@/lib/validators";

export async function GET(request: NextRequest) {
  const params = Object.fromEntries(request.nextUrl.searchParams.entries());
  const q = inventoryQuerySchema.parse(params);
  const where = {
    ...(q.q ? { OR: [{ sku: { contains: q.q, mode: "insensitive" as const } }, { name: { contains: q.q, mode: "insensitive" as const } }] } : {}),
  };
  const [total, products] = await Promise.all([
    prisma.product.count({ where }),
    prisma.product.findMany({
      where,
      skip: (q.page - 1) * q.limit,
      take: q.limit,
      orderBy: { updatedAt: "desc" },
      include: { variants: { include: { stocks: { include: { warehouse: true, location: true } } } } },
    }),
  ]);
  return NextResponse.json({ total, page: q.page, data: products });
}

export async function POST(request: NextRequest) {
  const body = stockAdjustmentSchema.parse(await request.json());
  const result = await prisma.$transaction(async (tx) => {
    const stock = await tx.stock.upsert({
      where: { variantId_warehouseId_locationId: { variantId: body.variantId, warehouseId: body.warehouseId, locationId: body.locationId ?? null } },
      create: { variantId: body.variantId, warehouseId: body.warehouseId, locationId: body.locationId, quantity: Math.max(0, body.quantity), reserved: 0 },
      update: { quantity: { increment: body.quantity } },
    });
    await tx.stockMovement.create({
      data: {
        variantId: body.variantId,
        warehouseId: body.warehouseId,
        locationId: body.locationId,
        type: body.quantity >= 0 ? "ADJUSTMENT_IN" : "ADJUSTMENT_OUT",
        quantity: body.quantity,
        beforeQty: Math.max(0, stock.quantity - body.quantity),
        afterQty: stock.quantity,
        note: body.note,
      },
    });
    return stock;
  });
  return NextResponse.json({ ok: true, stock: result });
}
