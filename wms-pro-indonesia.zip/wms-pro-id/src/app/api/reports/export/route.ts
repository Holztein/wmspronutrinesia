import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { ordersToXlsx, simplePdf } from "@/lib/export/report";

export async function GET(request: NextRequest) {
  const format = request.nextUrl.searchParams.get("format") ?? "csv";
  const orders = await prisma.order.findMany({ take: 500, orderBy: { orderedAt: "desc" }, include: { items: true } });
  const rows = orders.map((o) => ({
    orderNo: o.orderNo,
    marketplace: o.marketplace,
    status: o.status,
    customer: o.customerName,
    total: Number(o.grandTotal),
    courier: o.courier ?? "-",
    trackingNumber: o.trackingNumber ?? "-",
    orderedAt: o.orderedAt.toISOString(),
  }));
  if (format === "xlsx") {
    const buffer = ordersToXlsx(rows);
    return new NextResponse(buffer, { headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Content-Disposition": "attachment; filename=laporan-pesanan.xlsx" } });
  }
  if (format === "pdf") {
    const buffer = simplePdf("Laporan Pesanan WMS Pro", rows.slice(0, 30).map((r) => `${r.orderNo} | ${r.marketplace} | ${r.status} | Rp${r.total}`));
    return new NextResponse(buffer, { headers: { "Content-Type": "application/pdf", "Content-Disposition": "attachment; filename=laporan-pesanan.pdf" } });
  }
  const csv = [Object.keys(rows[0] ?? {}).join(","), ...rows.map((r) => Object.values(r).map((v) => `"${String(v).replaceAll('"', '""')}"`).join(","))].join("\n");
  return new NextResponse(csv, { headers: { "Content-Type": "text/csv", "Content-Disposition": "attachment; filename=laporan-pesanan.csv" } });
}
