import { Barcode, Download, FileSpreadsheet, PackagePlus, Search, Upload } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { rupiah } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function InventoryPage() {
  const products = await prisma.product.findMany({
    take: 50,
    orderBy: { updatedAt: "desc" },
    include: { variants: { include: { stocks: { include: { warehouse: true, location: true } } } } },
  });
  const warehouses = await prisma.warehouse.findMany({ where: { isActive: true } });
  return (
    <div className="space-y-6">
      <section className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div><h1 className="text-2xl font-bold tracking-tight md:text-3xl">Manajemen Inventory</h1><p className="text-muted-foreground">Master produk, varian SKU, barcode, multi-warehouse, low-stock alert, dan batch stock update.</p></div>
        <div className="flex flex-wrap gap-2"><Button><PackagePlus className="h-4 w-4" /> Produk Baru</Button><Button variant="outline"><Upload className="h-4 w-4" /> Import CSV/Excel</Button><Button variant="outline"><Download className="h-4 w-4" /> Export</Button></div>
      </section>
      <section className="grid gap-4 md:grid-cols-3">
        {warehouses.map((w) => (
          <Card key={w.id}><CardContent className="p-5"><div className="text-sm text-muted-foreground">Gudang</div><div className="mt-1 text-xl font-bold">{w.name}</div><div className="text-sm text-muted-foreground">{w.city}, {w.province}</div></CardContent></Card>
        ))}
      </section>
      <Card>
        <CardHeader className="gap-3 md:flex-row md:items-center md:justify-between">
          <CardTitle>Daftar SKU & Stok</CardTitle>
          <div className="relative w-full md:max-w-sm"><Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" /><Input placeholder="Cari SKU, barcode, nama produk..." className="pl-9" /></div>
        </CardHeader>
        <CardContent>
          <Table>
            <THead><TR><TH>Produk</TH><TH>Varian</TH><TH>Barcode</TH><TH>Stok Total</TH><TH>Reserved</TH><TH>Harga</TH><TH>Status</TH></TR></THead>
            <TBody>
              {products.flatMap((p) => p.variants.map((v) => {
                const total = v.stocks.reduce((a, s) => a + s.quantity, 0);
                const reserved = v.stocks.reduce((a, s) => a + s.reserved, 0);
                const low = total <= p.lowStockThreshold;
                return <TR key={v.id}><TD><div className="font-semibold">{p.name}</div><div className="text-xs text-muted-foreground">{p.sku} · {p.category}</div></TD><TD><div className="font-medium">{v.sku}</div><div className="text-xs text-muted-foreground">{v.color ?? "-"} / {v.size ?? "-"}</div></TD><TD><div className="flex items-center gap-2"><Barcode className="h-4 w-4 text-muted-foreground" />{v.barcode}</div></TD><TD className="font-bold">{total}</TD><TD>{reserved}</TD><TD>{rupiah.format(Number(v.sellPrice))}</TD><TD><Badge variant={low ? "danger" : "success"}>{low ? "Low Stock" : "Aman"}</Badge></TD></TR>;
              }))}
            </TBody>
          </Table>
        </CardContent>
      </Card>
      <Card>
        <CardHeader><CardTitle>Fitur Operasional Inventory</CardTitle></CardHeader>
        <CardContent className="grid gap-3 md:grid-cols-3">
          <div className="rounded-xl border p-4"><FileSpreadsheet className="mb-3 h-5 w-5 text-primary" /><div className="font-semibold">Import/Export Massal</div><p className="text-sm text-muted-foreground">Template Excel/CSV untuk update harga, stok, varian, barcode, dan listing marketplace.</p></div>
          <div className="rounded-xl border p-4"><Barcode className="mb-3 h-5 w-5 text-primary" /><div className="font-semibold">Scan Barcode/QR</div><p className="text-sm text-muted-foreground">Siap memakai ZXing Browser untuk scan di kamera HP/tablet gudang.</p></div>
          <div className="rounded-xl border p-4"><PackagePlus className="mb-3 h-5 w-5 text-primary" /><div className="font-semibold">Auto Reorder Suggestion</div><p className="text-sm text-muted-foreground">Reorder point per produk untuk saran restock, transfer gudang, dan pencegahan overselling.</p></div>
        </CardContent>
      </Card>
    </div>
  );
}
