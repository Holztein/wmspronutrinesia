import { Bell, Building2, KeyRound, ReceiptText, ShieldCheck, Truck, Users, Warehouse } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const [company, users, accounts, warehouses, rules] = await Promise.all([
    prisma.companyProfile.findFirst(),
    prisma.user.findMany({ orderBy: { role: "asc" } }),
    prisma.marketplaceAccount.findMany({ orderBy: { marketplace: "asc" } }),
    prisma.warehouse.findMany(),
    prisma.shippingRule.findMany({ where: { isActive: true } }),
  ]);
  return (
    <div className="space-y-6">
      <section><h1 className="text-2xl font-bold tracking-tight md:text-3xl">Settings & Konfigurasi</h1><p className="text-muted-foreground">Profil perusahaan, user RBAC, warehouse, marketplace API, kurir, notifikasi, invoice, dan pajak.</p></section>
      <section className="grid gap-4 xl:grid-cols-3">
        <Card><CardHeader><CardTitle className="flex items-center gap-2"><Building2 className="h-5 w-5" /> Profil Perusahaan</CardTitle></CardHeader><CardContent className="space-y-3"><Input defaultValue={company?.name ?? "PT Contoh Seller Nusantara"} /><Input defaultValue={company?.taxId ?? "NPWP belum diisi"} /><Input defaultValue={company?.email ?? "finance@contoh.co.id"} /><Button>Simpan Profil</Button></CardContent></Card>
        <Card><CardHeader><CardTitle className="flex items-center gap-2"><Warehouse className="h-5 w-5" /> Multi Warehouse</CardTitle></CardHeader><CardContent className="space-y-3">{warehouses.map((w) => <div key={w.id} className="rounded-xl border p-3"><div className="font-semibold">{w.code} · {w.name}</div><div className="text-sm text-muted-foreground">{w.city}, {w.province}</div></div>)}<Button variant="outline">Tambah Warehouse</Button></CardContent></Card>
        <Card><CardHeader><CardTitle className="flex items-center gap-2"><Truck className="h-5 w-5" /> Rule Pengiriman</CardTitle></CardHeader><CardContent className="space-y-3">{rules.map((r) => <div key={r.id} className="rounded-xl border p-3"><div className="font-semibold">{r.name}</div><div className="text-sm text-muted-foreground">{r.courier ?? "Semua kurir"} · gratis ongkir: {r.freeShipping ? "Ya" : "Tidak"}</div></div>)}<Button variant="outline">Tambah Rule</Button></CardContent></Card>
      </section>
      <Card><CardHeader><CardTitle className="flex items-center gap-2"><KeyRound className="h-5 w-5" /> Koneksi Marketplace</CardTitle></CardHeader><CardContent><Table><THead><TR><TH>Marketplace</TH><TH>Nama Toko</TH><TH>Shop ID</TH><TH>Sync Interval</TH><TH>Status</TH></TR></THead><TBody>{accounts.map((a) => <TR key={a.id}><TD>{a.marketplace.replace("_", " ")}</TD><TD>{a.shopName}</TD><TD>{a.shopId}</TD><TD>{a.syncInterval} menit</TD><TD><Badge variant={a.isActive ? "success" : "secondary"}>{a.isActive ? "Aktif" : "Nonaktif"}</Badge></TD></TR>)}</TBody></Table></CardContent></Card>
      <section className="grid gap-4 lg:grid-cols-2">
        <Card><CardHeader><CardTitle className="flex items-center gap-2"><Users className="h-5 w-5" /> User Management & RBAC</CardTitle></CardHeader><CardContent><Table><THead><TR><TH>Nama</TH><TH>Email</TH><TH>Role</TH><TH>Status</TH></TR></THead><TBody>{users.map((u) => <TR key={u.id}><TD>{u.name}</TD><TD>{u.email}</TD><TD><Badge variant="outline">{u.role}</Badge></TD><TD>{u.status}</TD></TR>)}</TBody></Table></CardContent></Card>
        <Card><CardHeader><CardTitle className="flex items-center gap-2"><Bell className="h-5 w-5" /> Modul Konfigurasi Lain</CardTitle></CardHeader><CardContent className="grid gap-3 sm:grid-cols-2"><div className="rounded-xl border p-3"><ShieldCheck className="mb-2 h-5 w-5 text-primary" /><div className="font-semibold">Permission granular</div><p className="text-sm text-muted-foreground">Role Owner, Manager, Staff, Picker, Packer, Viewer.</p></div><div className="rounded-xl border p-3"><ReceiptText className="mb-2 h-5 w-5 text-primary" /><div className="font-semibold">Invoice & PPN</div><p className="text-sm text-muted-foreground">Template invoice, packing slip, dan tax setting.</p></div><div className="rounded-xl border p-3"><Bell className="mb-2 h-5 w-5 text-primary" /><div className="font-semibold">Email/WhatsApp</div><p className="text-sm text-muted-foreground">Placeholder WhatsApp Business API dan SMTP.</p></div><div className="rounded-xl border p-3"><KeyRound className="mb-2 h-5 w-5 text-primary" /><div className="font-semibold">API Key Vault</div><p className="text-sm text-muted-foreground">Simpan secret di env/server-side, bukan frontend.</p></div></CardContent></Card>
      </section>
    </div>
  );
}
