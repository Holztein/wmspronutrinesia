import { ClipboardCheck, MapPinned, PackageOpen, PackageSearch, ScanBarcode, Truck } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";

export const dynamic = "force-dynamic";

export default async function WarehousePage() {
  const [receiving, pickTasks, packTasks, warehouses] = await Promise.all([
    prisma.receivingNote.findMany({ take: 6, orderBy: { createdAt: "desc" }, include: { warehouse: true, items: true } }),
    prisma.pickTask.findMany({ take: 8, orderBy: { createdAt: "desc" }, include: { order: true, assignedTo: true, items: true } }),
    prisma.packingTask.findMany({ take: 8, orderBy: { createdAt: "desc" }, include: { order: true, assignedTo: true, items: true } }),
    prisma.warehouse.findMany({ include: { locations: true } }),
  ]);
  return (
    <div className="space-y-6">
      <section className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><h1 className="text-2xl font-bold tracking-tight md:text-3xl">Warehouse Operations</h1><p className="text-muted-foreground">Receiving, putaway, picking, packing, shipping, dan retur dalam satu workflow.</p></div><div className="flex gap-2"><Button><ScanBarcode className="h-4 w-4" /> Scan Barang</Button><Button variant="outline"><PackageSearch className="h-4 w-4" /> Generate Pick List</Button></div></section>
      <section className="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
        {[{ icon: PackageOpen, title: "Receiving", desc: "Terima barang masuk" }, { icon: MapPinned, title: "Putaway", desc: "Assign rak/bin" }, { icon: PackageSearch, title: "Picking", desc: "Pick list mobile" }, { icon: ClipboardCheck, title: "Packing", desc: "Verifikasi item" }, { icon: Truck, title: "Shipping", desc: "Label & resi" }, { icon: ScanBarcode, title: "Returns", desc: "Restock/dispose" }].map((x) => <Card key={x.title}><CardContent className="p-4"><x.icon className="mb-3 h-6 w-6 text-primary" /><div className="font-semibold">{x.title}</div><p className="text-sm text-muted-foreground">{x.desc}</p></CardContent></Card>)}
      </section>
      <section className="grid gap-4 lg:grid-cols-2">
        <Card><CardHeader><CardTitle>Pick List Aktif</CardTitle></CardHeader><CardContent><Table><THead><TR><TH>Order</TH><TH>Picker</TH><TH>Item</TH><TH>Status</TH></TR></THead><TBody>{pickTasks.map((t) => <TR key={t.id}><TD>{t.order.orderNo}</TD><TD>{t.assignedTo?.name ?? "Belum assign"}</TD><TD>{t.items.length} SKU</TD><TD><Badge variant={t.status === "DONE" ? "success" : "warning"}>{t.status}</Badge></TD></TR>)}</TBody></Table></CardContent></Card>
        <Card><CardHeader><CardTitle>Packing Queue</CardTitle></CardHeader><CardContent><Table><THead><TR><TH>Order</TH><TH>Packer</TH><TH>Item</TH><TH>Status</TH></TR></THead><TBody>{packTasks.map((t) => <TR key={t.id}><TD>{t.order.orderNo}</TD><TD>{t.assignedTo?.name ?? "Belum assign"}</TD><TD>{t.items.length} SKU</TD><TD><Badge variant={t.status === "DONE" ? "success" : "warning"}>{t.status}</Badge></TD></TR>)}</TBody></Table></CardContent></Card>
      </section>
      <section className="grid gap-4 lg:grid-cols-2">
        <Card><CardHeader><CardTitle>Receiving Terakhir</CardTitle></CardHeader><CardContent>{receiving.map((r) => <div key={r.id} className="mb-3 rounded-xl border p-3"><div className="font-semibold">{r.number} · {r.supplier}</div><div className="text-sm text-muted-foreground">{r.warehouse.name} · {r.items.length} item · {r.status}</div></div>)}</CardContent></Card>
        <Card><CardHeader><CardTitle>Peta Gudang & Bin</CardTitle></CardHeader><CardContent className="grid gap-3 md:grid-cols-3">{warehouses.map((w) => <div key={w.id} className="rounded-xl border p-4"><div className="font-semibold">{w.name}</div><div className="text-sm text-muted-foreground">{w.locations.length} lokasi bin aktif</div><div className="mt-2 flex flex-wrap gap-1">{w.locations.slice(0, 8).map((l) => <Badge key={l.id} variant="outline">{l.code}</Badge>)}</div></div>)}</CardContent></Card>
      </section>
    </div>
  );
}
