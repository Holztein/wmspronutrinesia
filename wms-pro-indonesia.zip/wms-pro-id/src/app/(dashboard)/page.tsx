import { AlertTriangle, Boxes, ClipboardList, RefreshCw, TrendingUp } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { KpiCard } from "@/components/dashboard/kpi-card";
import { MarketplacePie, SalesTrendChart, TurnoverBar } from "@/components/dashboard/charts";
import { rupiah } from "@/lib/utils";

export const dynamic = "force-dynamic";

async function getDashboardData() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const last7 = new Date(today);
  last7.setDate(last7.getDate() - 6);

  const [todayOrders, pendingOrders, lowStocks, todaySalesAgg, marketplaceGroups, notifications, recentOrders] = await Promise.all([
    prisma.order.count({ where: { orderedAt: { gte: today } } }),
    prisma.order.count({ where: { status: { in: ["NEW", "CONFIRMED", "PICKING", "PACKING"] } } }),
    prisma.stock.count({ where: { quantity: { lte: 10 } } }),
    prisma.order.aggregate({ where: { orderedAt: { gte: today } }, _sum: { grandTotal: true } }),
    prisma.order.groupBy({ by: ["marketplace"], _count: true, where: { orderedAt: { gte: last7 } } }),
    prisma.notification.findMany({ take: 5, orderBy: { createdAt: "desc" } }),
    prisma.order.findMany({ take: 6, orderBy: { orderedAt: "desc" }, include: { warehouse: true, items: true } }),
  ]);

  const rawOrders = await prisma.order.findMany({ where: { orderedAt: { gte: last7 } }, select: { orderedAt: true, grandTotal: true } });
  const salesTrend = Array.from({ length: 7 }).map((_, idx) => {
    const d = new Date(last7);
    d.setDate(last7.getDate() + idx);
    const key = d.toISOString().slice(0, 10);
    const dayRows = rawOrders.filter((o) => o.orderedAt.toISOString().slice(0, 10) === key);
    return { date: key.slice(5), sales: dayRows.reduce((a, b) => a + Number(b.grandTotal), 0), orders: dayRows.length };
  });
  return {
    todayOrders,
    pendingOrders,
    lowStocks,
    todaySales: Number(todaySalesAgg._sum.grandTotal ?? 0),
    marketplace: marketplaceGroups.map((g) => ({ name: g.marketplace.replace("_", " "), value: g._count })),
    notifications,
    recentOrders,
    salesTrend,
    turnover: [
      { category: "Fashion", turnover: 4.2 },
      { category: "Beauty", turnover: 3.8 },
      { category: "Elektronik", turnover: 2.4 },
      { category: "Rumah Tangga", turnover: 2.9 },
      { category: "F&B", turnover: 5.1 },
    ],
  };
}

export default async function DashboardPage() {
  const data = await getDashboardData();
  return (
    <div className="space-y-6">
      <section className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-2xl font-bold tracking-tight md:text-3xl">Dashboard Operasional</h1>
          <p className="text-muted-foreground">Pantau order, stok, picking, packing, dan sinkronisasi marketplace secara real-time.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button><RefreshCw className="h-4 w-4" /> Sync Semua Marketplace</Button>
          <Button variant="outline">Generate Laporan</Button>
          <Button variant="outline">Lihat Low Stock</Button>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <KpiCard title="Pesanan Hari Ini" value={String(data.todayOrders)} hint="Order masuk sejak 00:00 WIB" icon={ClipboardList} />
        <KpiCard title="Pending Operasional" value={String(data.pendingOrders)} hint="Belum selesai picking/packing" icon={AlertTriangle} tone="warning" />
        <KpiCard title="Stok Menipis" value={String(data.lowStocks)} hint="Butuh restock atau transfer" icon={Boxes} tone="danger" />
        <KpiCard title="Penjualan Hari Ini" value={rupiah.format(data.todaySales)} hint="Gross sales multi-channel" icon={TrendingUp} tone="success" />
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <SalesTrendChart data={data.salesTrend} />
        <MarketplacePie data={data.marketplace} />
        <TurnoverBar data={data.turnover} />
      </section>

      <section className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>Pesanan Terbaru</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {data.recentOrders.map((order) => (
              <div key={order.id} className="flex flex-col gap-2 rounded-xl border p-3 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="font-semibold">{order.orderNo} · {order.customerName}</div>
                  <div className="text-sm text-muted-foreground">{order.marketplace.replace("_", " ")} · {order.warehouse?.name ?? "Belum assign"} · {order.items.length} item</div>
                </div>
                <div className="flex items-center gap-3"><Badge variant="secondary">{order.status}</Badge><span className="font-semibold">{rupiah.format(Number(order.grandTotal))}</span></div>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Notifikasi Penting</CardTitle></CardHeader>
          <CardContent className="space-y-3">
            {data.notifications.map((n) => <div key={n.id} className="rounded-xl border p-3"><Badge variant={n.level === "ERROR" ? "danger" : n.level === "WARNING" ? "warning" : "secondary"}>{n.level}</Badge><p className="mt-2 font-medium">{n.title}</p><p className="text-sm text-muted-foreground">{n.message}</p></div>)}
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
