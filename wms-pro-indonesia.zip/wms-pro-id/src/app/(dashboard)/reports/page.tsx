import { Download, FileBarChart, FileSpreadsheet, PieChart } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { rupiah } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function ReportsPage() {
  const salesByMarketplace = await prisma.order.groupBy({ by: ["marketplace"], _count: true, _sum: { grandTotal: true } });
  const products = await prisma.product.findMany({ take: 20, include: { variants: { include: { stocks: true } } } });
  return (
    <div className="space-y-6">
      <section className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><h1 className="text-2xl font-bold tracking-tight md:text-3xl">Reporting & Analytics</h1><p className="text-muted-foreground">Laporan penjualan, inventory aging, dead stock, ABC analysis, dan performa operasional.</p></div><div className="flex gap-2"><Button asChild><a href="/api/reports/export?format=xlsx"><FileSpreadsheet className="h-4 w-4" /> Export Excel</a></Button><Button asChild variant="outline"><a href="/api/reports/export?format=pdf"><Download className="h-4 w-4" /> Export PDF</a></Button><Button asChild variant="outline"><a href="/api/reports/export?format=csv">CSV</a></Button></div></section>
      <section className="grid gap-4 md:grid-cols-3">
        <Card><CardContent className="p-5"><FileBarChart className="mb-3 h-6 w-6 text-primary" /><div className="font-semibold">Sales Report</div><p className="text-sm text-muted-foreground">Per marketplace, produk, periode, biaya komisi.</p></CardContent></Card>
        <Card><CardContent className="p-5"><PieChart className="mb-3 h-6 w-6 text-primary" /><div className="font-semibold">Inventory Analytics</div><p className="text-sm text-muted-foreground">Aging stock, dead stock, turnover, ABC.</p></CardContent></Card>
        <Card><CardContent className="p-5"><Download className="mb-3 h-6 w-6 text-primary" /><div className="font-semibold">Operational SLA</div><p className="text-sm text-muted-foreground">Waktu picking/packing rata-rata dan error rate.</p></CardContent></Card>
      </section>
      <section className="grid gap-4 lg:grid-cols-2">
        <Card><CardHeader><CardTitle>Penjualan per Marketplace</CardTitle></CardHeader><CardContent><Table><THead><TR><TH>Marketplace</TH><TH>Order</TH><TH>Gross Sales</TH></TR></THead><TBody>{salesByMarketplace.map((s) => <TR key={s.marketplace}><TD>{s.marketplace.replace("_", " ")}</TD><TD>{s._count}</TD><TD className="font-semibold">{rupiah.format(Number(s._sum.grandTotal ?? 0))}</TD></TR>)}</TBody></Table></CardContent></Card>
        <Card><CardHeader><CardTitle>ABC & Low Stock Snapshot</CardTitle></CardHeader><CardContent className="space-y-2">{products.slice(0, 12).map((p, idx) => { const stock = p.variants.flatMap(v => v.stocks).reduce((a, s) => a + s.quantity, 0); return <div key={p.id} className="flex items-center justify-between rounded-xl border p-3"><div><div className="font-medium">{p.name}</div><div className="text-xs text-muted-foreground">{p.category} · stok {stock}</div></div><Badge variant={idx < 4 ? "success" : idx < 8 ? "warning" : "secondary"}>{idx < 4 ? "A" : idx < 8 ? "B" : "C"}</Badge></div>; })}</CardContent></Card>
      </section>
    </div>
  );
}
