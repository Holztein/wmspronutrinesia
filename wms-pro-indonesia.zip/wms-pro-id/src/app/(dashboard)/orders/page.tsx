import { CalendarDays, CheckSquare, Filter, PackageCheck, Truck } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TBody, TD, TH, THead, TR } from "@/components/ui/table";
import { rupiah, dateId } from "@/lib/utils";

export const dynamic = "force-dynamic";

const statusVariant: Record<string, "secondary" | "success" | "warning" | "danger"> = { NEW: "warning", CONFIRMED: "secondary", PICKING: "warning", PACKING: "warning", READY_TO_SHIP: "secondary", SHIPPED: "success", DELIVERED: "success", COMPLETED: "success", RETURNED: "danger", CANCELLED: "danger" };

export default async function OrdersPage() {
  const orders = await prisma.order.findMany({ take: 100, orderBy: { orderedAt: "desc" }, include: { items: true, warehouse: true } });
  return (
    <div className="space-y-6">
      <section className="flex flex-col justify-between gap-4 md:flex-row md:items-center"><div><h1 className="text-2xl font-bold tracking-tight md:text-3xl">Unified Order Inbox</h1><p className="text-muted-foreground">Semua order Shopee, TikTok Shop, Lazada, Tokopedia, dan manual dalam satu alur kerja.</p></div><div className="flex gap-2"><Button><CheckSquare className="h-4 w-4" /> Bulk Assign</Button><Button variant="outline"><PackageCheck className="h-4 w-4" /> Pick/Pack</Button><Button variant="outline"><Truck className="h-4 w-4" /> Ship</Button></div></section>
      <Card><CardHeader className="gap-3 md:flex-row md:items-center md:justify-between"><CardTitle>Filter Pesanan</CardTitle><div className="grid w-full gap-2 md:max-w-2xl md:grid-cols-4"><Input placeholder="Order/customer/resi" /><Button variant="outline"><Filter className="h-4 w-4" /> Marketplace</Button><Button variant="outline"><CalendarDays className="h-4 w-4" /> Tanggal</Button><Button variant="outline">Prioritas</Button></div></CardHeader><CardContent><Table><THead><TR><TH>Order</TH><TH>Marketplace</TH><TH>Customer</TH><TH>Gudang</TH><TH>Item</TH><TH>Total</TH><TH>Status</TH><TH>Kurir</TH></TR></THead><TBody>{orders.map((o) => <TR key={o.id}><TD><div className="font-semibold">{o.orderNo}</div><div className="text-xs text-muted-foreground">{dateId(o.orderedAt)}</div></TD><TD>{o.marketplace.replace("_", " ")}</TD><TD><div className="font-medium">{o.customerName}</div><div className="text-xs text-muted-foreground">{o.city}</div></TD><TD>{o.warehouse?.code ?? "Belum assign"}</TD><TD>{o.items.reduce((a, b) => a + b.qty, 0)} pcs</TD><TD className="font-semibold">{rupiah.format(Number(o.grandTotal))}</TD><TD><Badge variant={statusVariant[o.status] ?? "secondary"}>{o.status}</Badge></TD><TD><div>{o.courier ?? "-"}</div><div className="text-xs text-muted-foreground">{o.trackingNumber ?? "Belum ada resi"}</div></TD></TR>)}</TBody></Table></CardContent></Card>
    </div>
  );
}
