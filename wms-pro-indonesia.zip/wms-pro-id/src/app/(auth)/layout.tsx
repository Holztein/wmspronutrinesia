import * as React from "react";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return <main className="min-h-screen warehouse-grid">{children}</main>;
}
