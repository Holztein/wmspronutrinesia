import { ShieldCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LoginForm } from "@/components/login-form";

export default function LoginPage() {
  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-primary/10 text-primary"><ShieldCheck className="h-6 w-6" /></div>
          <CardTitle>Masuk WMS Pro</CardTitle>
          <p className="text-sm text-muted-foreground">Akun demo: owner@wmspro.id / password123</p>
        </CardHeader>
        <CardContent><LoginForm /></CardContent>
      </Card>
    </div>
  );
}
